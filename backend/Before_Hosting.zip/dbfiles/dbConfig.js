const config = {
  user: 'sssdatap_sa',
  password: 'sasasa-1_!_786',
  server: 'sssdataportal.com',
  database: 'sssdatap_MC',
  options: {
    trustServerCertificate: true,
    trustedConnection: false,
    enableArithAbort: true,
  },
  port: 1433,
  //
};

export default config;
