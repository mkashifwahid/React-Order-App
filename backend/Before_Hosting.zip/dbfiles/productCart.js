class product {
  constructor(productId, productName) {
    (this.productid = productId), (this.productName = productName);
  }
}

export default product;
